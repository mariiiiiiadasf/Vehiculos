package com.example.Trabajo01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabajo01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
