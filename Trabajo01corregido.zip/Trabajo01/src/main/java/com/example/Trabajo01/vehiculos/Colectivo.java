package com.example.Trabajo01.vehiculos;

public class Colectivo extends Vehiculo {
    
    public Colectivo(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    public void fabricarSinRadio() {
        this.radio = null; 
    }
}