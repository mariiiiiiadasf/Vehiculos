package com.example.Trabajo01.vehiculos;

public class Radio {
    private String marca;
    private int potencia;

    public Radio(String marca, int potencia) {
        this.marca = marca;
        this.potencia = potencia;
    }

}