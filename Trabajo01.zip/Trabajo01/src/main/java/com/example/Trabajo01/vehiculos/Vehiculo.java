package com.example.Trabajo01.vehiculos;

public abstract class Vehiculo {
    protected String marca;
    protected String modelo;
    protected String color;
    protected Radio radio;
    protected Double precio;

    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public void cambiarRadio(Radio nuevaRadio) {
        this.radio = nuevaRadio;
    }
    
    public boolean tieneRadio() {
        return radio != null;
    }
}