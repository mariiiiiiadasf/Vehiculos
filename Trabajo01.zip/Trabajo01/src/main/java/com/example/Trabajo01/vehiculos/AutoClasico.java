package com.example.Trabajo01.vehiculos;

public class AutoClasico extends Vehiculo {
    
    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    public void fabricarSinRadio() {
        this.radio = null; 
    }
}