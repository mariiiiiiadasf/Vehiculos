package com.example.Trabajo01.vehiculos;

public class AutoNuevo extends Vehiculo {
    
    public AutoNuevo(String marca, String modelo, String color) {
        super(marca, modelo, color);
        this.radio = new Radio("Philips", 100);
    }
}