package com.example.Trabajo01.test;

import com.example.Trabajo01.vehiculos.Colectivo;
import com.example.Trabajo01.vehiculos.AutoClasico;
import com.example.Trabajo01.vehiculos.AutoNuevo;
import com.example.Trabajo01.vehiculos.Radio;

public class TestVehiculos {
    public static void main(String[] args) {
        System.out.println("-- Test Vehículos --");

        // Prueba de Auto Clásico
        AutoClasico autoClasico = new AutoClasico("Ford", "Model T", "Negro");
        autoClasico.fabricarSinRadio();
        System.out.println("Auto Clásico sin radio: " + (autoClasico.tieneRadio() ? "Error" : "Correcto"));

        // Prueba de Auto Nuevo
        AutoNuevo autoNuevo = new AutoNuevo("Toyota", "Corolla", "Rojo");
        System.out.println("Auto Nuevo con radio: " + (autoNuevo.tieneRadio() ? "Correcto" : "Error"));

        // Cambiar radio en Auto Nuevo
        Radio nuevoRadio = new Radio("Sony", 120);
        autoNuevo.cambiarRadio(nuevoRadio);
        System.out.println("Auto Nuevo después de cambiar radio: " + (autoNuevo.tieneRadio() ? "Correcto" : "Error"));

        // Prueba de Colectivo
        Colectivo colectivo = new Colectivo("Mercedes", "Sprinter", "Blanco");
        colectivo.fabricarSinRadio();
        System.out.println("Colectivo sin radio: " + (colectivo.tieneRadio() ? "Error" : "Correcto"));
    }
}