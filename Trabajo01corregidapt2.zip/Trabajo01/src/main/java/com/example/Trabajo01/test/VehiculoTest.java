package com.example.Trabajo01.test;

import com.example.Trabajo01.vehiculos.AutoNuevo;
import com.example.Trabajo01.vehiculos.AutoClasico;
import com.example.Trabajo01.vehiculos.Colectivo;
import com.example.Trabajo01.vehiculos.Radio;


public class VehiculoTest {
   
    public static void main(String[] args) {
        AutoNuevo autoNuevo = new AutoNuevo("Toyota", "Corolla", "Rojo");
        AutoClasico autoClasico = new AutoClasico("Ford", "Mustang", "Negro");
        Colectivo colectivo = new Colectivo("Mercedes", "Sprinter", "Blanco");
        Radio radio = new Radio("Sony",55);

        // Probar que el Auto Nuevo tiene Radio al crear
        System.out.println("Auto Nuevo tiene Radio: " + autoNuevo.tieneRadio());

        // Probar que el Auto Clásico puede agregar Radio
        autoClasico.cambiarRadio("Sony", 80);
        System.out.println("Auto Clásico tiene Radio después de agregar: " + autoClasico.tieneRadio());

        // Probar que el Colectivo puede fabricarse sin Radio
        colectivo.fabricarSinRadio();
        System.out.println("Colectivo tiene Radio después de fabricarse sin Radio: " + colectivo.tieneRadio());

        // Probar que el Auto Clásico puede fabricarse sin Radio y luego agregarlo
        autoClasico.fabricarSinRadio();
        System.out.println("Auto Clásico tiene Radio después de fabricarse sin Radio: " + autoClasico.tieneRadio());
        autoClasico.cambiarRadio("Bose", 120);
        System.out.println("Auto Clásico tiene Radio después de agregar: " + autoClasico.tieneRadio());

        // Comprobar que el Colectivo no tiene instancia pura
        System.out.println("Colectivo creado: " + (colectivo != null));

        // Imprimir las clases
        System.out.println(autoNuevo);
        System.out.println(autoClasico);
        System.out.println(colectivo);
        System.out.println(radio);
  
    }
}