package com.example.Trabajo01.vehiculos;

public abstract class Vehiculo {
    protected String marca;
    protected String modelo;
    protected String color;
    protected Radio radio;
    protected Double precio;

    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }


    public void cambiarRadio(String marca, int potencia) {
        this.radio = new Radio(marca, potencia); 
    }

    public boolean tieneRadio() {
        return radio != null;
    }


    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", radio=" + radio + ", precio="
                + precio + "]";
    }
}