package com.example.Trabajo01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trabajo01Application {

	public static void main(String[] args) {
		SpringApplication.run(Trabajo01Application.class, args);
	}

}
